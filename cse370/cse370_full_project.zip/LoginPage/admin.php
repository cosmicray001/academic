<?php
	session_start();
	require_once('dbconfig/config.php');
	//phpinfo();
?>
<html>
	<head><title>Admin Panel</title>
	<link rel="icon" type="image/png" href="images/icons/admin.svg"/></head>
	<body style="background-color:#34495e">
		<div id="particles-js" style="position:fixed;width:100%;z-index:-10;"></div>
		<script src="js/particles.js"></script> 
		<script src="js/app.js"></script>
		<?php
			echo "yo";
		?>
	</body>
</html>
